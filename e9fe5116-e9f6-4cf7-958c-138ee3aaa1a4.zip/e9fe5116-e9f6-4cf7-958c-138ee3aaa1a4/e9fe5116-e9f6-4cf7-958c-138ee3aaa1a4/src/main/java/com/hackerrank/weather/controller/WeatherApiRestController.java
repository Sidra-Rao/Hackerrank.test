package com.hackerrank.weather.controller;

import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.hackerrank.weather.customExceptions.DataExistsExcep;
import com.hackerrank.weather.customExceptions.DataNotFoundExcep;
import com.hackerrank.weather.model.Weather;
import com.hackerrank.weather.service.WeatherService;

@RestController
public class WeatherApiRestController {
	
	private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");

    private WeatherService service;

    @Autowired
    public WeatherApiRestController(WeatherService service) {
        this.service = service;
    }
    
    @PostMapping(value = "/weather")
    @ResponseStatus(HttpStatus.CREATED)
    public Weather createWeather(@RequestBody Weather weatherData) throws DataExistsExcep {
        return service.create(weatherData);
    }
    
    @GetMapping(value = "/weather")
    @ResponseStatus(HttpStatus.OK)
    public List<Weather> getAllData() {
        return service.getAllWeatherData();
    }
    
    @DeleteMapping(value = "/erase")
    @ResponseStatus(HttpStatus.OK)
    public void deleteAll() {
        service.deleteAllData();
    }
    
    @DeleteMapping(value = "/erase", params = {"start", "end", "lat", "lon"})
    @ResponseStatus(HttpStatus.OK)
    public void deleteByParam(@RequestParam("start") String startDate,
                                         @RequestParam("end") String endDate,
                                         @RequestParam("lat") float latitude,
                                         @RequestParam("lon") float longitude){

    	try{
        service.deleteSelectedData(sdf.parse(startDate),sdf.parse(endDate), latitude, longitude);
    	}catch(Exception ex){
    		//handle here
    	}
    }
    
    
    @GetMapping(value = "/weather",
	            params = {"lat", "lon"})
	@ResponseStatus(HttpStatus.OK)
	public List<Weather> getDataByLatitudeAndLongitude(
	        @RequestParam("lat") float latitude,
	        @RequestParam("lon") float longitude){
	    try {
			return service.getDataByLatitudeAndLongitude(latitude, longitude);
		} catch (DataNotFoundExcep e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}    
    
    
    @GetMapping(value = "/weather/temperature", params = {"start", "end"})
    @ResponseStatus(HttpStatus.OK)
    public List<Weather> getAllWeatherDataForGivenDateRange(
        @RequestParam("start") String startDate,
        @RequestParam("end") String endDate) throws Exception {

    	return service.getAllDataForGivenDateRange(sdf.parse(startDate),
    		sdf.parse(endDate));
    }
}
