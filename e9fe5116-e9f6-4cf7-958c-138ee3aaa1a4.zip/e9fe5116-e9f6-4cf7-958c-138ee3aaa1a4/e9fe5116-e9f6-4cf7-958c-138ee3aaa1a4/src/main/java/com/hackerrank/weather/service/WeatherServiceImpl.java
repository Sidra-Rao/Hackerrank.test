package com.hackerrank.weather.service;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hackerrank.weather.customExceptions.DataExistsExcep;
import com.hackerrank.weather.customExceptions.DataNotFoundExcep;
import com.hackerrank.weather.model.Weather;
import com.hackerrank.weather.repository.WeatherRepository;

@Service
public class WeatherServiceImpl implements WeatherService {

    private WeatherRepository repo;

    @Autowired
    public WeatherServiceImpl(WeatherRepository weatherRepository) {
        this.repo = weatherRepository;
    }


    @Override
    public Weather create(Weather weather) throws DataExistsExcep{

        if (repo.findOne(weather.getId()) != null)
            throw new DataExistsExcep();
        return repo.save(weather);
    }

    @Override
    @Transactional
    public void deleteAllData() {
    	repo.deleteAll();
    }   


    @Override
    public List<Weather> getAllWeatherData() {
        Iterable<Weather> all = repo.findAll();
        return Lists.newArrayList(all);

    }

    @Override
    public List<Weather> getDataByLatitudeAndLongitude(Float latitude, Float longitude) throws DataNotFoundExcep {

        List<Weather> data = repo.findDataByLatitudeAndLongitude(latitude, longitude);

        if (data.isEmpty())
            throw new DataNotFoundExcep();

        return data;
    }


	@Override
	public void deleteSelectedData(Date startDate, Date endDate, Float latitude,
			Float longitude) {
		repo.deleteSelectedData(startDate, endDate, latitude, longitude);
		
	}   
	
	 @Override
	    public List<Weather> getAllDataForGivenDateRange(Date startDate, Date endDate) {
	        List<Weather> data = repo.findDataForGivenDateRange(startDate, endDate);
	        return data;
	    }
}