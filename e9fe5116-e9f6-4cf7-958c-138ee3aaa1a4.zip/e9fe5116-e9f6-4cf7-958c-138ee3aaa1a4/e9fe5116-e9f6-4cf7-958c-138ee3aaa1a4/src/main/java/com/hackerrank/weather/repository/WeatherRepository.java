package com.hackerrank.weather.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.hackerrank.weather.model.Weather;

public interface WeatherRepository  extends CrudRepository<Weather, Long> {
	
	@Query("select w FROM Weather w where (w.location.latitude     = ?1) AND" +
            "   (w.location.longitude    = ?2)")
    List<Weather> findDataByLatitudeAndLongitude(float lati,float longi);
	
	 @Query("delete FROM Weather w " +
	            "where " +
	            "   w.dateRecorded BETWEEN ?1 AND ?2  " +
	            "   AND " +
	            "   (w.location.latitude     = ?3) AND" +
	            "   (w.location.longitude    = ?4)")
	 void deleteSelectedData(Date startDate, Date endDate, float lati,float longi);
	 
	 @Query("select w FROM Weather w " +
	            "   where " +
	            "   w.dateRecorded BETWEEN ?1 AND ?2")
	 List<Weather> findDataForGivenDateRange(Date startDate,Date endDate);

}
