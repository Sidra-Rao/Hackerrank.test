package com.hackerrank.weather.service;

import java.util.Date;
import java.util.List;

import com.hackerrank.weather.customExceptions.DataExistsExcep;
import com.hackerrank.weather.customExceptions.DataNotFoundExcep;
import com.hackerrank.weather.model.Weather;

public interface WeatherService{

    void deleteAllData();
    void deleteSelectedData(Date startDate, Date endDate, Float latitude, Float longitude);
    Weather create(Weather weather)throws DataExistsExcep;
    List<Weather> getAllWeatherData();
    List<Weather> getDataByLatitudeAndLongitude(Float  latitude, Float longitudde) throws DataNotFoundExcep;
    List<Weather> getAllDataForGivenDateRange(Date startDate, Date endDate);    
}